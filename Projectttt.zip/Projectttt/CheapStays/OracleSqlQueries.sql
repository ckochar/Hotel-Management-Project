
drop table users cascade constraints;

CREATE TABLE users(user_id varchar(4)  primary key, 
		  password varchar(20), 
                  role varchar(10), 
                  user_name varchar (20), 
                  mobile_no varchar(10), 
                  phone varchar(10), 
                  address varchar(25),
                  email varchar(25));
  
                  
drop SEQUENCE userId_seq;                
CREATE SEQUENCE userId_seq START WITH 101;


2.

drop table Hotels cascade constraints;

CREATE TABLE Hotels(hotel_id varchar(4) primary key, 
	city varchar(10), 
	hotel_name varchar (30), 
	address varchar(35), 
	description varchar(50), 
	avg_rate_per_night number(7,2), 
	phone_no1 varchar(10),
 	phone_no2 varchar(10),
 	rating varchar(4), 
	email varchar(30),
        fax varchar(15));


INSERT INTO Hotels VALUES('1001','Pune','City View Hotel','Pimple Saudagar','Located amidst mountains',15000.00,'9856741232',
'7789564256','4','cityviewhotel@gmail.com','011235');

INSERT INTO Hotels VALUES('1002','Mumbai','Hotel Mount View','Andheri East','Located near beach',20000.00,'9856741231',
'7789564244','5','hotelmountview@gmail.com','011785');

drop SEQUENCE hotel_seq;  
CREATE SEQUENCE hotel_seq START WITH 1000;



3.

drop table roomdetails cascade constraints;

create table roomdetails(hotel_id varchar(4) references Hotels(hotel_id) ,  room_id varchar(4),  room_no varchar(3),
room_type varchar(30), per_night_rate  number(8,2), availability char(1));

insert into roomdetails values('1001' , 'SNA1' , '501' ,'Standard non A/C room' ,12000.00 , 'Y');
insert into roomdetails values('1001' , 'SNA1' , '502' ,'Standard non A/C room' ,12000.00 , 'Y');

insert into roomdetails values('1001' , 'SA1' , '601' ,'Standard A/C room' ,18000.00 , 'Y');
insert into roomdetails values('1001' ,'EXE1' , '602','Executive A/C room' ,18000.00 , 'Y');

insert into roomdetails values('1001' , 'SA1' , '701' ,'Standard A/C room' ,25000.00 , 'Y');
insert into roomdetails values('1001' ,'EXE1' , '702','Executive A/C room' ,25000.00 , 'Y');

insert into roomdetails values('1001' , 'DEX1' , '801' ,'Deluxe A/C room ' ,30000.00 , 'Y');
insert into roomdetails values('1001' , 'DEX1' , '802' ,'Deluxe A/C room ' ,30000.00 , 'Y');

insert into roomdetails values('1002' , 'SNA2' , '101' ,'Standard non A/C room' ,15000.00 , 'Y');
insert into roomdetails values('1002' , 'SNA2' , '102' ,'Standard non A/C room' ,15000.00 , 'Y');

insert into roomdetails values('1002' , 'SA2' , '201' ,'Standard A/C room' ,22000.00 , 'Y');
insert into roomdetails values('1002' , 'SA2' , '202' ,'Standard A/C room' ,22000.00 , 'Y');

insert into roomdetails values('1002' ,'EXE2' , '301','Executive A/C room' ,30000.00 , 'Y');
insert into roomdetails values('1002' ,'EXE2' , '302','Executive A/C room' ,30000.00 , 'Y');

insert into roomdetails values('1002' , 'DEX2' , '401' ,'Deluxe A/C room ' ,40000.00 , 'Y');
insert into roomdetails values('1002' , 'DEX2' , '402' ,'Deluxe A/C room ' ,40000.00 , 'Y');



4.

drop table bookingdetails cascade constraints;

create table bookingdetails( booking_id number(6), room_id varchar(4),  
user_id varchar(4), booked_from date, 
booked_to date, amount number(9,2));

drop SEQUENCE booking_seq;  
CREATE SEQUENCE booking_seq START WITH 1001;








