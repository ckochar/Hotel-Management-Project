package com.capgemini.cheapstays.model.dao;

import java.util.List;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.exception.HotelException;


public interface HotelsDAO {
	
	public List<Hotel> getAllHotels() throws HotelException;
	public void addHotel(Hotel hotel) throws HotelException;
	public void updateHotel(Hotel hotel) throws HotelException;
	public void deleteHotel(Hotel hotel) throws HotelException;
	

}
