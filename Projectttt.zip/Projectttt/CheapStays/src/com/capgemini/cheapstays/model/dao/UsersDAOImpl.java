package com.capgemini.cheapstays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.factory.DBUtil;


public class UsersDAOImpl implements UsersDAO {

	@Override
	public void addUsers(Users user) throws UsersException {
		
		int userId = getSeqUserId();
		try(Connection con=DBUtil.getConnection()) {
			
			PreparedStatement pstm=con.prepareStatement("insert into users values(?,?,?,?,?,?,?,?)");
			
			pstm.setInt(1, userId);
			pstm.setString(2, user.getPassword());
			pstm.setString(3, user.getRole());
			pstm.setString(4, user.getUser_name());
			pstm.setString(5,user.getMobile_no());
			pstm.setString(6, user.getPhone());
			pstm.setString(7, user.getAddress());
			pstm.setString(8, user.getEmail());
			
			pstm.executeUpdate();
			
			
		} catch (Exception e) {
			throw new UsersException(e);
		}
		
	}

	@Override
	public Users validateUser(Users user) throws UsersException {
		try(Connection con=DBUtil.getConnection()) {
			
			PreparedStatement pstm=con.prepareStatement("select * from users where user_name=? and password=?");
			
			pstm.setString(1, user.getUser_name());
			pstm.setString(2, user.getPassword());
			
			ResultSet res= pstm.executeQuery();
			
			if(res.next()==false)
			{
				throw new UsersException("Username or password is wrong");
			}
			else
			{
				
				while(res.next()) {
					user.setUser_id(res.getInt(1));
				}
			
			}
			
		} catch (Exception e) {
			throw new UsersException(e.getMessage());
		}
		return user;
	}
	
	
	public static int getSeqUserId() {
		int userId= 0;
		String query = "SELECT userId_seq.nextval FROM DUAL";
		Connection con = null;
		
		try {
			con = DBUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet res = st.executeQuery(query);
			while(res.next()) {
				userId = res.getInt(1);
			}
		
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		return userId;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
