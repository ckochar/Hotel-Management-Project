package com.capgemini.cheapstays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.factory.DBUtil;
import com.capgemini.cheapstays.factory.DbUtilTest;

public class HotelsDAOImpl implements HotelsDAO {

	
	/**
	 *  Searching Hotels by hotel_id.
	 * 
	 */
	
	
	
	@Override
	public List<Hotel> getAllHotels() throws HotelException {
		
		List<Hotel> listOfHotels = new ArrayList<Hotel>();
		
		
		try (Connection con = DBUtil.getConnection()){
			
			Statement stml = con.createStatement();
			
			ResultSet res = stml.executeQuery("select * from hotels");
			
			while(res.next() == true) {
				Hotel hotel = new Hotel();
	
			
			 hotel.setHotel_id(res.getString("HOTEL_ID"));
			 hotel.setCity(res.getString("CITY"));
			 hotel.setHotel_name(res.getString("HOTEL_NAME"));
			 hotel.setAddress(res.getString("ADDRESS"));
			 hotel.setDescription(res.getString("DESCRIPTION"));
			 hotel.setAvg_rate_per_night(res.getFloat("AVG_RATE_PER_NIGHT"));
			 hotel.setPhone_no1(res.getString("PHONE_NO1"));
			 hotel.setPhone_no2(res.getString("PHONE_NO2"));
			 hotel.setRating(res.getString("RATING"));
			 hotel.setEmail(res.getString("EMAIL"));
			 hotel.setFax(res.getString("FAX"));
			 
			
			 
			 listOfHotels.add(hotel);
			 
			}
		
			 return listOfHotels; 
		 	
			
	} catch(Exception e) {
		throw new HotelException(e);
	}		
			
	
	} // end of searchHotel......
	
	
	
	

	@Override
	public void addHotel(Hotel hotel) throws HotelException {
		try(Connection con=DBUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement("INSERT INTO Hotels Values(?,?,?,?,?,?,?,?,?,?,?)");	
			pstm.setString(1, hotel.getHotel_id());
			pstm.setString(2, hotel.getCity());
			pstm.setString(3, hotel.getHotel_name());
			pstm.setString(4, hotel.getAddress());
			pstm.setString(5, hotel.getDescription());
			pstm.setFloat(6, hotel.getAvg_rate_per_night());
			pstm.setString(7, hotel.getPhone_no1());
			pstm.setString(8, hotel.getPhone_no2());
			pstm.setString(9, hotel.getRating());
			pstm.setString(10, hotel.getEmail());
			pstm.setString(11, hotel.getFax());
			
			pstm.executeUpdate();
			
			}catch (Exception e) {
				throw new HotelException(e);
			}
			
		
	}
	
	
	@Override
	public void updateHotel(Hotel hotel) throws HotelException {
		
		try(Connection con=DbUtilTest.getConnection())
		{
			PreparedStatement pstm =con.prepareStatement("UPDATE hotels set city=?,hotel_name=?,address=?,description=?,avg_rate_per_night=?,phone_no1=?,phone_no2=?,rating=?,email=?,fax=? where hotel_id=?)");
			
			pstm.setString(1, hotel.getCity());
			pstm.setString(2, hotel.getHotel_name());
			pstm.setString(3, hotel.getAddress());
			pstm.setString(4, hotel.getDescription());
			pstm.setDouble(5, hotel.getAvg_rate_per_night());
			pstm.setString(6, hotel.getPhone_no1());
			pstm.setString(7, hotel.getPhone_no2());
			pstm.setString(8, hotel.getRating());
			pstm.setString(9, hotel.getEmail());
			pstm.setString(10, hotel.getFax());
			pstm.setString(11, hotel.getHotel_id());
			
			
			
			int flag = pstm.executeUpdate();
			System.out.println("flag = " +flag);
			
		}catch(Exception e){
			throw new HotelException(e);
			
		}
		
	}

	@Override
	public void deleteHotel(Hotel hotel) throws HotelException {
		try(Connection con= DBUtil.getConnection())
		{
		PreparedStatement ps= con.prepareStatement("delete from hotels WHERE hotel_id=?");
		ps.setString(1, hotel.getHotel_id());
		ps.execute();
		}
		catch(Exception e)
			{
			throw new HotelException(e);
		}
	}
	
	
	

		
		
	} 
	
	
	
	
		

	
	



