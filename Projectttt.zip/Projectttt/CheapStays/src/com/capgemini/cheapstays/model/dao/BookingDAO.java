package com.capgemini.cheapstays.model.dao;

import com.capgemini.cheapstays.dto.Booking;
import com.capgemini.cheapstays.exception.BookingException;

public interface BookingDAO {
	
	public int insertBookingDetails(Booking booking) throws BookingException;

}
