package com.capgemini.cheapstays.model.dao;

import java.util.List;


import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.exception.RoomException;


public interface RoomsDAO {
	
	public List<Room> roomDetails(int noOfRooms, String typeOfRooms) throws RoomException;
	 public void addRoom(Room room) throws RoomException;
	 public void updateRoom(Room room) throws RoomException;
	  public void deleteRoom(Room room) throws RoomException;
	    

}
