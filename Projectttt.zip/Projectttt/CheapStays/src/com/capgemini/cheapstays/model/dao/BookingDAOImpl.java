package com.capgemini.cheapstays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.capgemini.cheapstays.dto.Booking;
import com.capgemini.cheapstays.exception.BookingException;
import com.capgemini.cheapstays.factory.DBUtil;

public class BookingDAOImpl implements BookingDAO {

	@Override
	public int insertBookingDetails(Booking booking) throws BookingException {
		
		int bookingId ;
		
		java.sql.Date sqldateFrom = toSQLDate(booking.getBookedFrom());
		java.sql.Date sqldateTo = toSQLDate(booking.getBookedTo());
		
		
		try (Connection con = DBUtil.getConnection()) {
			PreparedStatement pstm =
					con.prepareStatement("insert into bookingdetails values(?,?,?,?,?,?)");
			
			 bookingId = getSeqBookingId();
			
			
			
			pstm.setInt(1, bookingId);
			pstm.setString(2, booking.getRoomId());
			pstm.setInt(3, booking.getUserId());
			pstm.setDate(4, sqldateFrom);
			pstm.setDate(5, sqldateTo);
			pstm.setDouble(6, booking.getAmount());
			
			pstm.executeUpdate();
		
			
		} catch(Exception e) {
			e.printStackTrace();
			throw new BookingException("Problem in inserting.");
			
		}	
		
		return bookingId;

	}
	
	
	public static int getSeqBookingId() {
		int bookingId= 0;
		String query = "SELECT booking_seq.nextval FROM DUAL";
		Connection con = null;
		
		try {
			con = DBUtil.getConnection();
			Statement st = con.createStatement();
			ResultSet res = st.executeQuery(query);
			while(res.next()) {
				bookingId = res.getInt(1);
			}
		
		
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		
		return bookingId;
	}
	
	
	
	
	
	public java.sql.Date toSQLDate(Date date) {
		
		 java.sql.Date parsedDate = new java.sql.Date(date.getTime());
		
		return parsedDate;
		
	
	
	}
	
	
	
	

}
