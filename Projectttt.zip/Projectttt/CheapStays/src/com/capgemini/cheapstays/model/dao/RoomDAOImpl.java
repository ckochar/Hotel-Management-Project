package com.capgemini.cheapstays.model.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.factory.DBUtil;


public class RoomDAOImpl implements RoomsDAO {

	@Override
	public  List<Room> roomDetails(int noOfRooms ,String typeOfRooms) throws RoomException {
		 	int count = 0;
			Room room = null;
			List<Room> listOfRooms = new ArrayList<Room>();
		
		try(Connection con = DBUtil.getConnection())  {
			
			String roomId = RoomDAOImpl.getIdByRoomType(typeOfRooms);
			
			PreparedStatement pstm = 
					con.prepareStatement("select * from roomdetails where room_id= ? and  AVAILABILITY= 'Y'");
			
			pstm.setString(1, roomId);
			ResultSet res = pstm.executeQuery();
			
			while(res.next() == true) {
				 room = new Room();
				room.setHotel_id(res.getString(1));
				room.setRoom_id(res.getString(2));
				room.setRoom_no(res.getString(3));
				room.setRoom_type(res.getString(4));
				room.setPer_night_rate(res.getDouble(5));
				room.setAvailability(res.getString(6));
				
				
				listOfRooms.add(room);
				count += 1;
			}
			
			
		  if(count < noOfRooms) {
				throw new RoomException("Not enough rooms available right now");
		
		  } else {
			for (int index = 0; index < count; index++) {
				RoomDAOImpl.updateAvailability(roomId);
			}
			
		} 
		  
	  } catch(ClassNotFoundException | SQLException e) {
			throw new RoomException(e);
		} 
		
		return listOfRooms;
		}	// end of roomDetails method.
	
	
	
	
	@Override
	public void addRoom(Room room) throws RoomException {
	try(Connection con=DBUtil.getConnection()) {
			
		PreparedStatement pstm=con.prepareStatement("INSERT INTO roomdetails values(?,?,?,?,?,?)");
		
		pstm.setString(1, room.getHotel_id());
		pstm.setString(2, room.getRoom_id());
		pstm.setString(3, room.getRoom_no()); 
		pstm.setString(4, room.getRoom_type());
		pstm.setDouble(5, room.getPer_night_rate());
		pstm.setString(6, room.getAvailability());
			
			pstm.executeUpdate();
			
			
		} catch (Exception e) {
			throw new RoomException(e);
		}
		
	}

	@Override
	public void updateRoom(Room room) throws RoomException {
		
		try(Connection con= DBUtil.getConnection())
		{
			PreparedStatement pstm =con.prepareStatement("UPDATE roomdetails SET room_no=?,room_type=?,per_night_rate=?,availability=? where hotel_id=? and room_id=?");
			
			
			pstm.setString(1, room.getRoom_no());
			pstm.setString(2, room.getRoom_type());
			pstm.setDouble(3, room.getPer_night_rate());
			pstm.setString(4, room.getAvailability());
			pstm.setString(5, room.getHotel_id());
			pstm.setString(6, room.getRoom_id());
		
			pstm.executeUpdate();
		}
		catch(Exception e){
			throw new RoomException(e);
			
		}
	}

	
	
	

	@Override
	public void deleteRoom(Room room) throws RoomException {
		try(Connection con= DBUtil.getConnection())
		{
		PreparedStatement ps= con.prepareStatement("delete from roomdetails WHERE room_id=?");

				ps.setString(1,room.getRoom_id());
				ps.execute();
			}
			catch(Exception e)
				{
				throw new RoomException(e);
			}
		
	}
	
	
	
	
	
	

	
	
	
	
	
	

	public static void updateAvailability(String roomId) {
		try (Connection con = DBUtil.getConnection()){
		
		PreparedStatement pstm = 
				con.prepareStatement("update roomdetails set AVAILABILITY ='N' where room_id=?");
		
		pstm.setString(1, roomId);
		pstm.executeUpdate();
		
		
		} catch (Exception e) {
			
		}
	
	}
	
	
	public static String getIdByRoomType(String roomType) {
		
		String roomId = null;
		
		
		try(Connection con = DBUtil.getConnection())  {
		
		PreparedStatement pstm = 
				con.prepareStatement("select room_id from roomdetails where room_type= ? ");
		
		pstm.setString(1, roomType);
		ResultSet res = pstm.executeQuery();
		
		while(res.next() == true) {
		 roomId = res.getString("room_id");
		}
		
	  } catch (Exception e) {
		  System.out.println(e.getMessage());
	  }
		return roomId;
	}
	
	
	
	



	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

