package com.capgemini.cheapstays.dto;

public class Room {
	
	private String hotel_id, room_id ,room_no ,room_type ,availability;
	
	private double  per_night_rate;
	
	
	public Room(String hotel_id, String room_id, String room_no,
			String room_type, String availability, double per_night_rate) {
		super();
		this.hotel_id = hotel_id;
		this.room_id = room_id;
		this.room_no = room_no;
		this.room_type = room_type;
		this.availability = availability;
		this.per_night_rate = per_night_rate;
	}
	
	public Room() {
		
	}
	
	
	public String getHotel_id() {
		return hotel_id;
	}
	public void setHotel_id(String hotel_id) {
		this.hotel_id = hotel_id;
	}
	public String getRoom_id() {
		return room_id;
	}
	public void setRoom_id(String room_id) {
		this.room_id = room_id;
	}
	public String getRoom_no() {
		return room_no;
	}
	public void setRoom_no(String room_no) {
		this.room_no = room_no;
	}
	public String getRoom_type() {
		return room_type;
	}
	public void setRoom_type(String room_type) {
		this.room_type = room_type;
	}
	public String getAvailability() {
		return availability;
	}
	public void setAvailability(String availability) {
		this.availability = availability;
	}
	public double getPer_night_rate() {
		return per_night_rate;
	}
	public void setPer_night_rate(double per_night_rate) {
		this.per_night_rate = per_night_rate;
	}


	
	@Override
	public String toString() {
		return "Room [hotel_id=" + hotel_id + ", room_id=" + room_id
				+ ", room_no=" + room_no + ", room_type=" + room_type
				+ ", availability=" + availability + ", per_night_rate="
				+ per_night_rate + "]";
	}
	
	
	
	

	
	
}
