package com.capgemini.cheapstays.dto;

import java.io.Serializable;
import java.util.Date;



public class Booking implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private int bookingId, userId;
	private String roomId ;
	private Date bookedFrom, bookedTo;
	private double amount;
	
	
	
	public Booking() {
		
	}



	public Booking(int bookingId, String roomId, int userId,
			Date bookedFrom, Date bookedTo, double amount) {
		super();
		this.bookingId = bookingId;
		this.roomId = roomId;
		this.userId = userId;
		this.bookedFrom = bookedFrom;
		this.bookedTo = bookedTo;
		this.amount = amount;
	}



	public int getBookingId() {
		return bookingId;
	}



	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}



	public String getRoomId() {
		return roomId;
	}



	public void setRoomId(String roomId) {
		this.roomId = roomId;
	}



	public int getUserId() {
		return userId;
	}



	public void setUserId(int userId2) {
		this.userId = userId2;
	}



	public Date getBookedFrom() {
		return bookedFrom;
	}



	public void setBookedFrom(Date bookedFrom) {
		this.bookedFrom = bookedFrom;
	}



	public Date getBookedTo() {
		return bookedTo;
	}



	public void setBookedTo(Date bookedTo) {
		this.bookedTo = bookedTo;
	}



	public double getAmount() {
		return amount;
	}



	public void setAmount(double amount) {
		this.amount = amount;
	}



	public static long getSerialversionuid() {
		return serialVersionUID;
	}



	@Override
	public String toString() {
		return "Booking [bookingId=" + bookingId + ", roomId=" + roomId
				+ ", userId=" + userId + ", bookedFrom=" + bookedFrom
				+ ", bookedTo=" + bookedTo + ", amount=" + amount + "]";
	}
	
	
	
	
	
	
	
	
	

}
