package com.capgemini.cheapstays.exception;

public class RoomException extends Exception {

	public RoomException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RoomException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RoomException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
