package com.capgemini.cheapstays.exception;

public class HotelException extends Exception {

	public HotelException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HotelException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public HotelException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
