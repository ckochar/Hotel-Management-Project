package com.capgemini.cheapstays.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;


import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;





import javax.servlet.http.HttpSession;

import com.capgemini.cheapstays.dto.Booking;
import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.BookingException;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.service.AdminService;
import com.capgemini.cheapstays.service.AdminServiceImpl;
import com.capgemini.cheapstays.service.HotelsService;
import com.capgemini.cheapstays.service.HotelsServiceImpl;

// http://localhost:8081/CheapStays/index.html


@WebServlet("/UsersFrontController")
public class UsersFrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	
	private HotelsService hotelService;
	private AdminService adminService;
       
  
    public UsersFrontController() {
    	hotelService = new HotelsServiceImpl();
    	adminService = new AdminServiceImpl();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request,response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		HttpSession userSession = request.getSession(false);
		
		if(userSession == null) {
			RequestDispatcher requestDispatcher =
					request.getRequestDispatcher("Error.jsp");
		
			request.setAttribute("errorMessage", "You need to login first.<a href = 'Login.jsp'>Click Here </a> to login");
			requestDispatcher.forward(request, response);
			return;
		
		}
		
		String action= request.getParameter("action");
		
		switch(action)
		{
		
		case "adduser":
		{
			
			String password=request.getParameter("password");
			String role=request.getParameter("role");
			String user_name=request.getParameter("user_name");
			String mobile_no=request.getParameter("mobile_no");
			String phone=request.getParameter("phone");
			String address=request.getParameter("address");
			String email=request.getParameter("email");
			
			
			Users user = new Users();
			user.setPassword(password);
			user.setRole(role);
			user.setUser_name(user_name);
			user.setMobile_no(mobile_no);
			user.setPhone(phone);
			user.setAddress(address);
			user.setEmail(email);
	
			
			try {
				hotelService.addUsers(user);
				
				RequestDispatcher rd=request.getRequestDispatcher("index.html");
				rd.forward(request, response);
				
			} catch (UsersException e) {
				
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
			break;
		}  //end of case add....
		
		
		

		 case "login": {
			
			String username = request.getParameter("username");
			String password = request.getParameter("password");
			
			try {
				Users user = hotelService.validateUser(username, password);
				
				if(user != null) {
					int userId = user.getUser_id();
						
				HttpSession session = 
						request.getSession(true);
				
				session.setAttribute("userId", userId);
					RequestDispatcher rd =
							request.getRequestDispatcher("MainOptions.jsp");
					
					rd.forward(request, response);
					return;
			
				} 
				else {
					
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", "User with"+ username + "does not exsist");
				rd.forward(request, response);
				break;
				
			}
			
			} catch (UsersException e) {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", e.getMessage());
				
				rd.forward(request, response);
			
				break;
		}
			
	} //end of case login....
		
		
		
			
			
			case "hoteldetails" : {
				 try {
					List<Hotel> hotelList = 
							 hotelService.getAllHotels();
					
					RequestDispatcher rd =
							request.getRequestDispatcher("HotelList.jsp");
					
					request.setAttribute("hotelList", hotelList);
					rd.forward(request, response);
					break;
				
				 }catch (HotelException e) {
					RequestDispatcher rd =
							request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
					break;
				}
				 
			} //end of case hoteldetails...
			
			
			
			
			 case "bookroompage": {
				 RequestDispatcher rd =
							request.getRequestDispatcher("BookRoom.jsp");
				
				 rd.forward(request, response);
				 break;
			}	//end of bookroompage case
			 
			 
			 
			 
			 case "fetchDetails": {
				 int noOfRooms =  Integer.parseInt(request.getParameter("numberofrooms"));
				 String typeOfRooms =request.getParameter("roomtype");
				 
				 double per_night_rate = 0;	 
				 String availability = null;
				 String avail = null;
				 String roomId = null;
				 
				 try {
					List<Room> rooms = hotelService.roomDetails(noOfRooms, typeOfRooms);
					
					for (Room room : rooms) {
						 per_night_rate=  room.getPer_night_rate();
						 availability  = room.getAvailability();
						
						
					}
					
					HttpSession session = 
							request.getSession(false);
					session.setAttribute("pernightrate", per_night_rate);
					session.setAttribute("roomId", roomId);
					
					if(availability.equalsIgnoreCase("Y")) {
						avail = "Available"; 
					} else {
						 avail = "Not Available";
					}
					
					RequestDispatcher rd = 
							request.getRequestDispatcher("BookRoom.jsp");
					request.setAttribute("perNightRate", per_night_rate);
					request.setAttribute("availability", avail);
					
				
					
					rd.forward(request, response);	
					 
			   } catch (RoomException e) {
						
					e.printStackTrace();
				}
				 
				break;
				 
			 } // end of bookroom
			 
			 
	     case "bookingDetailsPage" : {
	    	 RequestDispatcher rd =
						request.getRequestDispatcher("BookingDetails.jsp");

				HttpSession session = 
						request.getSession(false);
				session.getAttribute("userId");
				session.getAttribute("roomId");
	    	 
			
			 rd.forward(request, response);
			 break;
	    	 
	     }	 
	     
	     
	     case "bookroom": {
	    	 String bookFrom = request.getParameter("book_from");
	    	 String bookTo = request.getParameter("book_to");
	    	 
	    	 double amount = 0.0;
	    	 long diff = 0;
	    	 Date dateFrom = new Date();
	    	 Date dateTo = new Date();
	    	 
	    	 DateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);
	    	 try {
				 dateFrom = format.parse(bookFrom);
				 dateTo = format.parse(bookTo);
				 
				 System.out.println(dateTo);
				 
				diff = dateTo.getTime() - dateFrom.getTime();
				diff = diff/86400000;
			 
				  HttpSession session = 
							request.getSession(false);
				
		    		
				  int userId = (int) session.getAttribute("userId");
		    	  double perNightRate = (double) session.getAttribute("pernightrate");
		    	  String roomId = (String) session.getAttribute("roomId");
		   
		    		amount = diff*perNightRate;
		    		request.setAttribute("amount", amount);
		    		
		    		Booking booking = new Booking();
		    		
		    		booking.setUserId(userId);
		    		booking.setRoomId(roomId);
		    		booking.setBookedTo(dateTo);
		    		booking.setBookedFrom(dateFrom);
		    		booking.setAmount(amount);
		    	
		    		int bookingId = hotelService.insertBookingDetails(booking);
		    		session.setAttribute("bookingId", bookingId);
		    		
		 
		    		 RequestDispatcher rd =
								request.getRequestDispatcher("BookingDetails.jsp");
		    		 request.setAttribute("amount", amount);
		    		 rd.forward(request, response);
	    		 
	    	 }	catch (ParseException | BookingException e) {
				RequestDispatcher rd =
						request.getRequestDispatcher("Error.jsp");
				
				request.setAttribute("errorMessage", e.getMessage());
				
				rd.forward(request, response);
			
				break;
	     }
	    	 
	 }   	 
	     
	     
	     
	     
	     case "success": {
	    	
	    	 RequestDispatcher rd =
						request.getRequestDispatcher("suucess.jsp");
			
			 rd.forward(request, response);
			 break;
	    	 
	    	 
	     }
	     
	     
	     
	     
	     
	     
	     case "addRoom": {
			 String hotel_Id = request.getParameter("hotel_Id");
			 String room_id = request.getParameter("room_Id");
			 String room_no = request.getParameter("room_No");
			 String room_type = request.getParameter("roomtype");
			 double per_night_rate = Double.parseDouble(request.getParameter("PER_NIGHT_RATE"));
			 String availability= request.getParameter("Availability");
			 
			 Room room = new Room();
			 room.setHotel_id(hotel_Id);
			 room.setRoom_id(room_id);
			 room.setRoom_no(room_no);
			 room.setRoom_type(room_type);
			 room.setPer_night_rate(per_night_rate);
			 room.setAvailability(availability);
			 
			 try{
				 adminService.addRoom(room);
				RequestDispatcher rd=request.getRequestDispatcher("MainOptionsAdmin.jsp");
				rd.forward(request, response);
				
			} catch (RoomException e) {
				
				RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage", e.getMessage());
				rd.forward(request, response);
			}
			break;
		}  //end of add room
		 
		 
			 
		 case "updateRoom":  {
			 
			 String room_Id = request.getParameter("room_Id");
			 
			 String hotel_Id = request.getParameter("hotel_Id");
			 String room_id = request.getParameter("room_id");
			 String room_no = request.getParameter("room_no");
			 String room_type = request.getParameter("room_type");
			 double per_night_rate =Double.parseDouble(request.getParameter("PER_NIGHT_RATE"));
			 String availability= request.getParameter("availability");
			 
			 Room room = new Room();
			 room.setHotel_id(hotel_Id);
			 room.setRoom_id(room_id);
			 room.setRoom_no(room_no);
			 room.setRoom_type(room_type);
			 room.setPer_night_rate(per_night_rate);
			 room.setAvailability(availability);
			 
			 try{
				 adminService.updateRoom(room);
					RequestDispatcher rd=request.getRequestDispatcher("MainOptionsAdmin.jsp");
					rd.forward(request, response);
					
				} catch (RoomException e) {
					
					RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
				break;
			 
		 }  //end of update Room
		 
		 case "deleteRoom":	{
			 
			 String room_id = request.getParameter("Room_Id");
			 try {
				 adminService.deleteRoom(room_id);
					RequestDispatcher rd = request.getRequestDispatcher("MainOptionsAdmin.jsp");
					
					
					rd.forward(request, response);
				
				} 
				catch (RoomException e) {
					
					RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
					
					request.setAttribute("errorMessage", e.getMessage());
					rd.forward(request, response);
				}
		 }
			 case "addHotel": {
				 String hotelId= request.getParameter("hotelId");
				 String City= request.getParameter("City");
				 String hotelName= request.getParameter("hotelName");
				 String address= request.getParameter("address");
				 String description= request.getParameter("description");
				 float AVG_RATE_PER_NIGHT= Float.parseFloat(request.getParameter("AVG_RATE_PER_NIGHT"));
				 String PHONE_NO1= request.getParameter("PHONE_NO1");
				 String PHONE_NO2= request.getParameter("PHONE_NO2");
				 String Rating= request.getParameter("Rating");
				 String Email= request.getParameter("Email");
				 String FAX= request.getParameter("FAX");
				 
				 Hotel hotel = new Hotel();
				 hotel.setHotel_id(hotelId);
				 hotel.setCity(City);
				 hotel.setHotel_name(hotelName);
				 hotel.setAddress(address);
				 hotel.setDescription(description);
				 hotel.setAvg_rate_per_night(AVG_RATE_PER_NIGHT);
				 hotel.setPhone_no1(PHONE_NO1);
				 hotel.setPhone_no2(PHONE_NO2);
				 hotel.setRating(Rating);
				 hotel.setEmail(Email);
				 hotel.setFax(FAX);
				 try{
					 adminService.addHotel(hotel);;
						RequestDispatcher rd=request.getRequestDispatcher("MainOptionsAdmin.jsp");
						rd.forward(request, response);
						
					} catch (HotelException e) {
						
						RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMessage", e.getMessage());
						rd.forward(request, response);
					}
					break;
			 }
			 
			 case "updateHotel": {
				 String hotelId= request.getParameter("hotelId");
				 String City= request.getParameter("City");
				 String hotelName= request.getParameter("hotelName");
				 String address= request.getParameter("address");
				 String description= request.getParameter("description");
				 float AVG_RATE_PER_NIGHT= Float.parseFloat(request.getParameter("AVG_RATE_PER_NIGHT"));
				 String PHONE_NO1= request.getParameter("PHONE_NO1");
				 String PHONE_NO2= request.getParameter("PHONE_NO2");
				 String Rating= request.getParameter("Rating");
				 String Email= request.getParameter("Email");
				 String FAX= request.getParameter("FAX");
				 
				 Hotel hotel = new Hotel();
				 hotel.setHotel_id(hotelId);
				 hotel.setCity(City);
				 hotel.setHotel_name(hotelName);
				 hotel.setAddress(address);
				 hotel.setDescription(description);
				 hotel.setAvg_rate_per_night(AVG_RATE_PER_NIGHT);
				 hotel.setPhone_no1(PHONE_NO1);
				 hotel.setPhone_no2(PHONE_NO2);
				 hotel.setRating(Rating);
				 hotel.setEmail(Email);
				 hotel.setFax(FAX);
				
				 try{
					 adminService.updateHotel(hotel);
						RequestDispatcher rd=request.getRequestDispatcher("MainOptionsAdmin.jsp");
						rd.forward(request, response);
						
					} catch (HotelException e) {
						
						RequestDispatcher rd=request.getRequestDispatcher("Error.jsp");
						request.setAttribute("errorMessage", e.getMessage());
						rd.forward(request, response);
					}
					break;
			 }
			 
			 case "deleteHotel": {
				 
				 String hotel_id = request.getParameter("hotelId");
				 try {
					 adminService.deleteHotel(hotel_id);
						RequestDispatcher rd = request.getRequestDispatcher("MainOptionsAdmin.jsp");
						
						
						rd.forward(request, response);
					
					} 
					catch (HotelException e) {
						
						RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
						
						request.setAttribute("errorMessage", e.getMessage());
						rd.forward(request, response);
					}
				 
				 
			 }
	    	 
	    	 
	  		
				
					
					
				
				 
				 
				
				
				 
				 
				 
				 
				 
				 
				 
		
			
			default:
			{
				RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
				request.setAttribute("errorMessage","The page you requested does not exist");
				rd.forward(request, response);
				break;
			}
			
			
			
		}	
	}


}
