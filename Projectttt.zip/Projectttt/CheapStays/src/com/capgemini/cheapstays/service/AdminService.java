package com.capgemini.cheapstays.service;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;

public interface AdminService {
	
		public void addRoom(Room room) throws RoomException;
	    public void updateRoom(Room room) throws RoomException;
	    public void deleteRoom(String room_id) throws RoomException;
	    public void addHotel(Hotel hotel) throws HotelException;
		public void updateHotel(Hotel hotel) throws HotelException;
		public void deleteHotel(String hotel_id) throws HotelException;

}
