package com.capgemini.cheapstays.service;

import java.util.List;

import com.capgemini.cheapstays.dto.Booking;
import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.BookingException;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.exception.UsersException;


public interface HotelsService {
	
	
	
	public List<Hotel> getAllHotels() throws HotelException;
	
	public void addUsers(Users user) throws UsersException;
	
	public Users validateUser(String username, String password) throws UsersException;
	
	public List<Room> roomDetails(int noOfRooms ,String typeOfRooms) throws RoomException;
	
	public int insertBookingDetails(Booking booking) throws BookingException;
	
	
}
