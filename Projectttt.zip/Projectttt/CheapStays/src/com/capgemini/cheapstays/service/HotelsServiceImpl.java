package com.capgemini.cheapstays.service;

import java.util.List;

import com.capgemini.cheapstays.dto.Booking;
import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.dto.Users;
import com.capgemini.cheapstays.exception.BookingException;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.exception.UsersException;
import com.capgemini.cheapstays.model.dao.BookingDAO;
import com.capgemini.cheapstays.model.dao.BookingDAOImpl;
import com.capgemini.cheapstays.model.dao.HotelsDAO;
import com.capgemini.cheapstays.model.dao.HotelsDAOImpl;
import com.capgemini.cheapstays.model.dao.RoomDAOImpl;
import com.capgemini.cheapstays.model.dao.RoomsDAO;
import com.capgemini.cheapstays.model.dao.UsersDAO;
import com.capgemini.cheapstays.model.dao.UsersDAOImpl;


public class HotelsServiceImpl implements HotelsService {
	
	private UsersDAO usersDAO;
	private HotelsDAO hotelDAO;
	private RoomsDAO roomDAO;
	private BookingDAO bookingDAO;
	
	public HotelsServiceImpl() {
		usersDAO=new UsersDAOImpl();
		hotelDAO =new HotelsDAOImpl();
		roomDAO = new RoomDAOImpl();
		bookingDAO = new BookingDAOImpl();
	}
	
	

	@Override
	public void addUsers(Users user) throws UsersException {
		usersDAO.addUsers(user);
	}
	
	
	
	
	
	
	@Override
	public Users validateUser(String username, String password) throws UsersException {
		
		Users user=new Users();
		user.setUser_name(username);
		user.setPassword(password);
	
		return usersDAO.validateUser(user);
	} //end of validateUsers....

	
	
	@Override
	public List<Hotel> getAllHotels() throws HotelException {
		
		return hotelDAO.getAllHotels();
			
		
	}

	@Override
	public List<Room> roomDetails(int noOfRooms, String typeOfRooms)
			throws RoomException {
		
		List<Room> rooms = roomDAO.roomDetails(noOfRooms, typeOfRooms);
		
		return rooms;
		
	
	}

	@Override
	public int insertBookingDetails(Booking booking) throws BookingException {
		return bookingDAO.insertBookingDetails(booking);
		
	}




}
