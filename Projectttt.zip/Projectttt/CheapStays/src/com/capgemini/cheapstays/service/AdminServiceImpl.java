package com.capgemini.cheapstays.service;

import com.capgemini.cheapstays.dto.Hotel;
import com.capgemini.cheapstays.dto.Room;
import com.capgemini.cheapstays.exception.HotelException;
import com.capgemini.cheapstays.exception.RoomException;
import com.capgemini.cheapstays.model.dao.HotelsDAO;
import com.capgemini.cheapstays.model.dao.HotelsDAOImpl;
import com.capgemini.cheapstays.model.dao.RoomDAOImpl;
import com.capgemini.cheapstays.model.dao.RoomsDAO;

public class AdminServiceImpl implements AdminService {
	

	private HotelsDAO hotelDAO;
	private RoomsDAO roomDAO;
	
	public AdminServiceImpl() {
		hotelDAO =new HotelsDAOImpl();
		roomDAO = new RoomDAOImpl();
	
		
	}
	

	@Override
	public void addRoom(Room room) throws RoomException {
		roomDAO.addRoom(room);
		
	} // end of add rooms

	
	@Override
	public void updateRoom(Room room) throws RoomException {
		roomDAO.updateRoom(room);
		
	} // end of update rooms
	

	@Override
	public void deleteRoom(String room_id) throws RoomException {
		Room room = new Room();
		room.setRoom_id(room_id);
		roomDAO.deleteRoom(room);
		
	} // end of delete rooms

	@Override
	public void addHotel(Hotel hotel) throws HotelException {
		hotelDAO.addHotel(hotel);
		
	}

	@Override
	public void updateHotel(Hotel hotel) throws HotelException {
		hotelDAO.updateHotel(hotel);
		
	}

	@Override
	public void deleteHotel(String hotel_id) throws HotelException {
		Hotel hotel = new Hotel();
		hotel.setHotel_id(hotel_id);
		hotelDAO.deleteHotel(hotel);
		
	}
	

}
